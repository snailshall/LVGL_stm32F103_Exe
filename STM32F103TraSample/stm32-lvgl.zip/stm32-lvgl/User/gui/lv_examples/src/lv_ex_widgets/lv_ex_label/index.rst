C
^

Label recoloring and scrolling 
"""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_label/lv_ex_label_1
  :language: c

Text shadow 
""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_label/lv_ex_label_2
  :language: c

Align labels 
""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_label/lv_ex_label_3
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
