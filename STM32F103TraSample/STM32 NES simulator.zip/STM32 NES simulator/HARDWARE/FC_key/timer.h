#ifndef __TIMER_H__
#define __TIMER_H__

#include "stm32f10x.h"

void TIM3_Config(uint16_t arr, uint16_t psc);

#endif // __TIMER_H__
