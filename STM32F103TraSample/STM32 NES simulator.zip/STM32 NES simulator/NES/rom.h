#ifndef _ROM_H_
#define _ROM_H_
extern unsigned char rom_file[];
#endif
